package com.screenoncall

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import okhttp3.*
import org.webrtc.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    // Replace with your deployed secure WebSocket URL from server/README.md.
    private val signalingUrl = "wss://YOUR-SIGNALING-SERVER.example/ws"
    private lateinit var status: TextView
    private lateinit var roomInput: EditText
    private lateinit var client: OkHttpClient
    private var socket: WebSocket? = null
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var localAudio: AudioSource? = null
    private var room = ""
    private var joined = false
    private var muted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32, 48, 32, 32); setBackgroundColor(0xFF24142E.toInt()) }
        val title = TextView(this).apply { text = "DEEP SPACE  ∞"; textSize = 29f; setTextColor(0xFFE6E7EB.toInt()); gravity = Gravity.CENTER }
        val desc = TextView(this).apply { text = "Private voice • screen-lock friendly\nBoth phones need internet"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFFE6E7EB.toInt()) }
        roomInput = EditText(this).apply { hint = "Enter same room code on both phones"; setSingleLine(true); setTextColor(0xFFE6E7EB.toInt()); setHintTextColor(0xFFB8AFC2.toInt()); setHintTextColor(0xFFB8AFC2.toInt()); backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFF4B942.toInt()) }
        status = TextView(this).apply { text = "Not connected"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFFF4B942.toInt()) }
        fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setTextColor(0xFF24142E.toInt()); backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFF4B942.toInt()); setOnClickListener { action() } }
        root.addView(title); root.addView(space(20)); root.addView(desc); root.addView(space(22)); root.addView(roomInput)
        root.addView(button("CONNECT", ::connect)); root.addView(button("MUTE / UNMUTE", { muted = !muted; audioTrack?.setEnabled(!muted); status.text = if (muted) "Microphone muted" else "Microphone on" }))
        root.addView(button("DISCONNECT", ::disconnect)); root.addView(space(14)); root.addView(status)
        setContentView(root)
        client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        initializeWebRtc()
    }
    private fun space(dp: Int) = TextView(this).apply { height = (dp * resources.displayMetrics.density).toInt() }
    private fun initializeWebRtc() {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions())
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }
    private fun connect() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { status.text = "Allow microphone permission, then tap CONNECT"; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return }
        room = roomInput.text.toString().trim().uppercase()
        if (room.length < 4) { status.text = "Enter a room code (at least 4 characters)"; return }
        if (signalingUrl.contains("YOUR-SIGNALING-SERVER")) { status.text = "Setup needed: deploy the included signaling server and add its WSS URL (see README)."; return }
        status.text = "Connecting…"
        val request = Request.Builder().url(signalingUrl).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) { ws.send(JSONObject().put("type", "join").put("room", room).toString()) }
            override fun onMessage(ws: WebSocket, text: String) { runOnUiThread { handleSignal(JSONObject(text)) } }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) { runOnUiThread { status.text = "Connection failed: ${t.message ?: "check internet/server"}" } }
            override fun onClosed(ws: WebSocket, code: Int, reason: String) { runOnUiThread { status.text = "Disconnected" } }
        })
    }
    private fun handleSignal(msg: JSONObject) {
        when (msg.optString("type")) {
            "joined" -> { joined = true; startKeepAlive(); status.text = "Room joined. Waiting for the other person…" }
            "peer-joined" -> {
                status.text = "Partner found. Starting voice call…"
                try {
                    makePeer()
                    createOffer()
                } catch (t: Throwable) {
                    Log.e("DeepSpaceCall", "Failed while creating peer/offer", t)
                    status.text = "Call setup failed: ${t.javaClass.simpleName}. Disconnect and retry."
                }
            }
            "offer" -> {
                try {
                    makePeer()
                    peer?.setRemoteDescription(object : SdpObserverAdapter() {
                        override fun onSetSuccess() { runOnUiThread { createAnswer() } }
                        override fun onSetFailure(error: String?) { runOnUiThread { status.text = "Offer rejected: ${error ?: "unknown SDP error"}" } }
                    }, SessionDescription(SessionDescription.Type.OFFER, msg.getString("sdp")))
                } catch (t: Throwable) {
                    Log.e("DeepSpaceCall", "Failed while applying remote offer", t)
                    status.text = "Call setup failed: ${t.javaClass.simpleName}. Disconnect and retry."
                }
            }
            "answer" -> peer?.setRemoteDescription(SdpObserverAdapter(), SessionDescription(SessionDescription.Type.ANSWER, msg.getString("sdp")))
            "ice" -> try { val c = msg.getJSONObject("candidate"); peer?.addIceCandidate(IceCandidate(c.getString("sdpMid"), c.getInt("sdpMLineIndex"), c.getString("candidate"))) } catch (_: Exception) {}
            "error" -> status.text = msg.optString("message", "Signaling error")
            "peer-left" -> status.text = "Partner disconnected"
        }
    }
    private fun makePeer() {
        if (peer != null) return
        try {
            val pcFactory = factory ?: throw IllegalStateException("WebRTC factory is not ready")
            val ice = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            peer = pcFactory.createPeerConnection(PeerConnection.RTCConfiguration(ice), object : PeerConnection.Observer {
                override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                    Log.d("DeepSpaceCall", "ICE connection state: $s")
                    runOnUiThread {
                        if (s == PeerConnection.IceConnectionState.CONNECTED || s == PeerConnection.IceConnectionState.COMPLETED) status.text = "Voice connected • screen can be locked"
                        if (s == PeerConnection.IceConnectionState.FAILED) status.text = "Call connection failed; try again"
                    }
                }
                override fun onIceConnectionReceivingChange(b: Boolean) {}
                override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(c: IceCandidate?) {
                    if (c != null) socket?.send(JSONObject().put("type", "ice").put("room", room).put("candidate", JSONObject().put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex).put("candidate", c.sdp)).toString())
                }
                override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
                override fun onAddStream(s: MediaStream?) {}
                override fun onRemoveStream(s: MediaStream?) {}
                override fun onDataChannel(c: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
                override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
                override fun onTrack(transceiver: RtpTransceiver?) {}
            }) ?: throw IllegalStateException("WebRTC could not create a peer connection")
            val constraints = MediaConstraints()
            localAudio = pcFactory.createAudioSource(constraints)
            audioTrack = pcFactory.createAudioTrack("voice0", localAudio)
            audioTrack?.let { peer?.addTrack(it, listOf("voice")) }
            Log.d("DeepSpaceCall", "Peer connection and local audio track created")
        } catch (t: Throwable) {
            Log.e("DeepSpaceCall", "makePeer failed", t)
            status.text = "Call setup failed: ${t.javaClass.simpleName}"
            throw t
        }
    }
    private fun createOffer() {
        val pc = peer ?: throw IllegalStateException("Peer connection is missing")
        pc.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                if (sdp == null) { runOnUiThread { status.text = "Offer creation failed" }; return }
                pc.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        socket?.send(JSONObject().put("type", "offer").put("room", room).put("sdp", sdp.description).toString())
                        Log.d("DeepSpaceCall", "Offer created and local description set")
                    }
                    override fun onSetFailure(error: String?) { runOnUiThread { status.text = "Offer setup failed: ${error ?: "unknown SDP error"}" } }
                }, sdp)
            }
            override fun onCreateFailure(error: String?) { runOnUiThread { status.text = "Offer creation failed: ${error ?: "unknown error"}" } }
        }, MediaConstraints())
    }
    private fun createAnswer() {
        val pc = peer ?: return
        pc.createAnswer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                if (sdp == null) { runOnUiThread { status.text = "Answer creation failed" }; return }
                pc.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() { socket?.send(JSONObject().put("type", "answer").put("room", room).put("sdp", sdp.description).toString()) }
                    override fun onSetFailure(error: String?) { runOnUiThread { status.text = "Answer setup failed: ${error ?: "unknown SDP error"}" } }
                }, sdp)
            }
            override fun onCreateFailure(error: String?) { runOnUiThread { status.text = "Answer creation failed: ${error ?: "unknown error"}" } }
        }, MediaConstraints())
    }
    private fun startKeepAlive() { val i = Intent(this, CallKeepAliveService::class.java); if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
    private fun disconnect() { try { socket?.send(JSONObject().put("type", "leave").put("room", room).toString()); socket?.close(1000, "user disconnected") } catch (_: Exception) {}; socket = null; peer?.close(); peer?.dispose(); peer = null; audioTrack?.dispose(); audioTrack = null; localAudio?.dispose(); localAudio = null; stopService(Intent(this, CallKeepAliveService::class.java)); joined = false; status.text = "Disconnected" }
    override fun onDestroy() { super.onDestroy(); disconnect(); client.dispatcher.executorService.shutdown() }
}
open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}
