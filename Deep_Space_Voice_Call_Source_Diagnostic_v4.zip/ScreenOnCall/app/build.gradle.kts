plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.screenoncall"
    compileSdk = 35
    defaultConfig { applicationId = "com.screenoncall"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("org.webrtc:google-webrtc:1.0.32006")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
