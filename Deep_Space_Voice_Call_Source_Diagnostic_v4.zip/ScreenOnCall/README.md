# Deep Space — Screen-Locked Voice Call — minimal voice-call app

A fresh, minimal Android project for one purpose: two people join the same room code, make a live voice call, lock the screen, and keep talking until Disconnect. It uses WebRTC audio and a small WebSocket signaling server. Normal mobile internet (3G/4G/5G) or Wi-Fi is enough; 5G is not required.

## Important honest status

This is **source code, not a tested/installable APK**. This environment does not have Android Gradle tooling installed, so I could not build or test the APK here. The app will not connect until you deploy the signaling server over HTTPS/WSS and replace the placeholder URL in `MainActivity.kt`. Reliable calling across restrictive mobile networks may also require a TURN relay service; this first version only configures Google's public STUN server. Do not treat this as production-ready or share it with strangers.

## 1. Deploy signaling server

Deploy the `server/` folder to a Node.js host that supports persistent WebSockets. Set its start command to `npm start` and expose it behind HTTPS with WebSocket support. The server listens on `PORT` (default 8080), and the WebSocket path is `/ws`. The public address must be `wss://your-domain/ws`.

The included signaling server is intentionally minimal and does not authenticate room ownership. Use a private, hard-to-guess room code and only share it with the intended person. For real-world use, add authentication, rate limiting, and a TURN service.

## 2. Set the server URL

Open `app/src/main/java/com/screenoncall/MainActivity.kt` and replace:

`wss://YOUR-SIGNALING-SERVER.example/ws`

with your deployed WSS URL.

## 3. Build the APK with GitHub Actions

1. Upload this project to a new GitHub repository (keep `.github/workflows/android-build.yml`).
2. Open **Actions → Build Deep Space APK → Run workflow**.
3. When it succeeds, open that run and download the **Screen-On-Call-APK** artifact.
4. Extract the artifact ZIP and install `app-debug.apk` on both Android phones.

## 4. Call

1. Both people install the same build and allow microphone permission.
2. Enter the exact same room code on both phones.
3. Tap **CONNECT** on both. Keep the app open until status says the voice is connected.
4. Lock the screen. Android shows an ongoing-call notification while the foreground service is active.
5. Open the app and tap **DISCONNECT** to end the call.

## Limits

- Both phones need an active internet connection. A cellular signal with no mobile data, no Wi-Fi, or airplane mode without Wi-Fi will not work.
- Screen locked/off is supported in principle by the foreground service, but some phone battery optimizers can still interrupt calls; allow background activity for the app if needed.
- A fully powered-off phone cannot make or receive a live call.
- The first version has no account system, call history, push notification for incoming calls, or guaranteed network traversal. Both people must open the app and connect using the same room code.
